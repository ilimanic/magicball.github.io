﻿{
	"version": 1596136423,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/bg_idle-sheet0.png",
		"images/bg_start-sheet0.png",
		"images/sprite-sheet0.png",
		"images/bg_load-sheet0.png",
		"images/bg_load-sheet1.png",
		"images/bg_load-sheet2.png",
		"images/bg_delete-sheet0.png",
		"media/bg_tap.ogg",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}